from pathlib import Path
import pandas as pd
import joblib
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import accuracy_score, classification_report

DATA_DIR = Path("data")
MODEL_PATH = Path("model.pkl")
VECTORIZER_PATH = Path("vectorizer.pkl")

def load_dataset():
    fake_file, real_file = DATA_DIR / "Fake.csv", DATA_DIR / "True.csv"
    if fake_file.exists() and real_file.exists():
        fake = pd.read_csv(fake_file)
        real = pd.read_csv(real_file)
        fake_text = fake.get("title", "").fillna("").astype(str) + " " + fake.get("text", "").fillna("").astype(str)
        real_text = real.get("title", "").fillna("").astype(str) + " " + real.get("text", "").fillna("").astype(str)
        data = pd.DataFrame({
            "text": pd.concat([fake_text, real_text], ignore_index=True),
            "label": ["Fake"] * len(fake_text) + ["Real"] * len(real_text)
        })
        data = data[data["text"].str.strip().str.len() > 20]
        return data
    sample = pd.read_csv(DATA_DIR / "sample_news.csv")
    return sample[["text", "label"]].dropna()

def train_model():
    data = load_dataset()
    if len(data) < 10:
        raise ValueError("Dataset is too small. Add Kaggle Fake.csv and True.csv to the data folder.")
    x_train, x_test, y_train, y_test = train_test_split(
        data["text"].astype(str), data["label"], test_size=0.2, random_state=42, stratify=data["label"]
    )
    vectorizer = TfidfVectorizer(stop_words="english", max_df=0.95, min_df=1, ngram_range=(1, 2))
    x_train_vec = vectorizer.fit_transform(x_train)
    x_test_vec = vectorizer.transform(x_test)
    model = MultinomialNB()
    model.fit(x_train_vec, y_train)
    predictions = model.predict(x_test_vec)
    print("Dataset records:", len(data))
    print("Test accuracy:", round(accuracy_score(y_test, predictions), 3))
    print(classification_report(y_test, predictions, zero_division=0))
    joblib.dump(model, MODEL_PATH)
    joblib.dump(vectorizer, VECTORIZER_PATH)
    print("Model and vectorizer saved.")
    return model

if __name__ == "__main__":
    train_model()
