from flask import Flask, render_template, request
import sqlite3
from pathlib import Path
import joblib
from train_model import train_model, MODEL_PATH, VECTORIZER_PATH

app = Flask(__name__)
DB_PATH = Path("data/history.db")

def init_db():
    DB_PATH.parent.mkdir(exist_ok=True)
    with sqlite3.connect(DB_PATH) as con:
        con.execute("""CREATE TABLE IF NOT EXISTS history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            headline TEXT, article TEXT, prediction TEXT, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )""")

def get_model():
    if not MODEL_PATH.exists() or not VECTORIZER_PATH.exists():
        train_model()
    return joblib.load(MODEL_PATH), joblib.load(VECTORIZER_PATH)

@app.route("/", methods=["GET", "POST"])
def index():
    result = None
    if request.method == "POST":
        headline = request.form.get("headline", "").strip()
        article = request.form.get("article", "").strip()
        combined = (headline + " " + article).strip()
        if len(combined.split()) < 5:
            result = {"error": "Please enter a headline and a little more article text (at least 5 words)."}
        else:
            model, vectorizer = get_model()
            prediction = model.predict(vectorizer.transform([combined]))[0]
            result = {"label": prediction}
            init_db()
            with sqlite3.connect(DB_PATH) as con:
                con.execute("INSERT INTO history (headline, article, prediction) VALUES (?, ?, ?)",
                            (headline, article, prediction))
    return render_template("index.html", result=result)

@app.route("/about")
def about():
    return render_template("about.html")

@app.route("/history")
def history():
    init_db()
    with sqlite3.connect(DB_PATH) as con:
        rows = con.execute("SELECT headline, prediction, created_at FROM history ORDER BY id DESC LIMIT 20").fetchall()
    return render_template("history.html", rows=rows)

if __name__ == "__main__":
    init_db()
    app.run(debug=True)
