# Presentation Outline

1. Title: Fake News Detection System
2. Problem: Misleading news can spread quickly online.
3. Objective: Classify news text into Real or Fake dataset labels.
4. Dataset: Kaggle Fake and Real News Dataset.
5. Technologies: Python, NLP, TF-IDF, Naive Bayes, Flask, SQLite.
6. Workflow: Input text -> TF-IDF feature extraction -> Naive Bayes model -> Prediction -> History.
7. Output: Predicted label shown on the web page.
8. Limitation: It is a text classifier, not an independent fact-checker.
9. Future scope: Model comparison, multilingual support and source verification.
