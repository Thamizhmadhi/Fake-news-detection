# Fake News Detection System

A student-level NLP and Machine Learning project. It uses TF-IDF to convert article text into numerical features and Multinomial Naive Bayes to classify an article as **Real** or **Fake**.

## Features
- Enter a news headline and article text
- Text-based prediction using an NLP/ML pipeline
- Stores recent predictions in a local SQLite database
- Shows basic model evaluation in the terminal when training

## Technologies
Python, Flask, Pandas, Scikit-learn, TF-IDF, Multinomial Naive Bayes, SQLite, HTML and CSS.

## Dataset setup
For the proper project experiment, download the Kaggle **Fake and Real News Dataset** and place these two files in the `data` folder:
- `Fake.csv`
- `True.csv`

The files should contain `title` and `text` columns. The training script assigns the labels based on the file names.

If those files are not present, the project uses `data/sample_news.csv`. This is a small, fictional demonstration dataset only, included so the application can be tested. It is not suitable for reporting real-world accuracy.

## Run on Windows
1. Install Python 3.10 or later.
2. Extract this ZIP file.
3. Open Command Prompt in the extracted project folder.
4. Create a virtual environment:
   `py -m venv venv`
5. Activate it:
   `venv\\Scripts\\activate`
6. Install packages:
   `pip install -r requirements.txt`
7. Train the model:
   `python train_model.py`
8. Start the website:
   `python app.py`
9. Open `http://127.0.0.1:5000` in your browser.

## Important limitation
This is an educational text classifier, not a professional fact-checking service. It learns language patterns from its training dataset. It does not independently verify sources, evidence, dates or claims. A prediction can be wrong, especially for new topics, short text, satire, or articles from a different region. Always check important news with reliable sources.

## Suggested project explanation
"This project uses Natural Language Processing and Machine Learning to study the text of a news article. First, the headline and article are cleaned and converted into TF-IDF features. Then, a Multinomial Naive Bayes model predicts whether the text resembles the Real or Fake examples in the training dataset. The website displays the result and saves recent predictions."
