# Project Report: Fake News Detection System

## 1. Introduction
Online news is shared quickly, and misleading information can be difficult to identify. This project demonstrates how Natural Language Processing (NLP) and Machine Learning can be used to classify news text into two dataset categories: Real and Fake.

## 2. Objective
To build a simple application that accepts a news headline and article text, processes the text, and predicts a label using a trained machine-learning model.

## 3. Dataset
The intended dataset is the Kaggle Fake and Real News Dataset, using `Fake.csv` and `True.csv`. The project also includes a small fictional sample dataset for checking that the application runs. The sample data must not be used to claim meaningful real-world accuracy.

## 4. Methodology
1. Load the news text and its label.
2. Combine the headline and article body.
3. Split the records into training and testing sets.
4. Convert text into TF-IDF features.
5. Train a Multinomial Naive Bayes classifier.
6. Evaluate it using accuracy and a classification report.
7. Save the trained model and vectorizer.
8. Connect them to the Flask application for prediction.

## 5. Modules
- Dataset loading
- Text feature extraction
- Model training and evaluation
- News prediction interface
- Prediction history

## 6. Expected Outcome
The application displays a predicted dataset label, either Real or Fake, and stores recent predictions locally.

## 7. Limitations
The model learns patterns from the supplied dataset; it does not verify facts or sources. Dataset bias, outdated articles, short text and unfamiliar topics can affect predictions. The output should be treated as a preliminary classification, not proof that a news story is true or false.

## 8. Future Enhancement
A future version could compare multiple models, support more languages, show confidence scores carefully, and connect predictions to independent fact-checking sources.
